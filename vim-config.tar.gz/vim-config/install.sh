#!/bin/bash

[ -e $HOME/.vimrc ] && mv $HOME/.vimrc $HOME/.vimrc.backup

[ -e $HOME/.vim ] && mv $HOME/.vim $HOME/.vim.backup

mkdir $HOME/.vim

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cp -R $DIR/* $HOME/.vim/

ln -s $HOME/.vim/vimrc $HOME/.vimrc

