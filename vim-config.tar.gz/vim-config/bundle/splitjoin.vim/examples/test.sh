echo "one; two"
echo "two"

echo "one"; (echo "two"; echo "three") &; echo "four"
