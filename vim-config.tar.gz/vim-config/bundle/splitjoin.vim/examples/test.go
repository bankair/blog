StructType{1, "asdf", []int{1, 2, 3}}

StructType{one: 1, two: "asdf", three: []int{1, 2, 3}}
