from foo import bar, baz
from foo import one,\
        two,\
        three

knights = {'gallahad': 'the pure', 'robin': 'the brave'}

spam = {'spam': [1, 2, 3], 'spam, spam': { 'one': 'two' }, "spam, spam, spam...": ('spam', 'eggs')}

spam = [1, [2, 3], 4]
spam = (1, (2, 3), 4)

if something: something_else(":")

while True: loop()

class Foo: pass

run("one", "two", "three {}".format(four))
