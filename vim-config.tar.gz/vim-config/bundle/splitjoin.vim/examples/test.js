var one = { one: "two", three: "four" };

var two = {
  one: "two",
  three: "four"
};

var three = { one: [two, three], four: "five, six", 'seven': /8, 9/ };

var callback = function (something, other) { something_else; };
function example(something, other) { something_else; }

var foo = [ 'baz', 'bar', 'froboz', 'gnusto' ];
