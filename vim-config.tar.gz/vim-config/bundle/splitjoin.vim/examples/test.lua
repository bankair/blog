local something = other(function (one, two)
  print("foo")
end)

function example ()
  print("foo")
  print("bar")
end

function example ()
end
