if (val1 && val2 || val3);

myfunction("lots", "of", "different", "parameters");
